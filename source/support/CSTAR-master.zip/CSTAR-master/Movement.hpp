/* 
 * File:   Movement.hpp
 * Author: matthewsupernaw
 *
 * Created on December 16, 2014, 1:51 PM
 */

#ifndef MOVEMENT_HPP
#define	MOVEMENT_HPP

namespace movement{
    
}

#endif	/* MOVEMENT_HPP */

