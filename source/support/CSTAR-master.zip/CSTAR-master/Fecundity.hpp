/* 
 * File:   Fecundity.hpp
 * Author: matthewsupernaw
 *
 * Created on December 16, 2014, 1:49 PM
 */

#ifndef FECUNDITY_HPP
#define	FECUNDITY_HPP

namespace cstar {

    namespace fecundity {

        template<class T>
        class FecundityBase {
        };
        
        namespace age_based {

        }

        namespace size_based {

        }

    }
}

#endif	/* FECUNDITY_HPP */

