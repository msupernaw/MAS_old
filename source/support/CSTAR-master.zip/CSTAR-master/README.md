CSTAR
=====

Common Stock Assessment Routines
