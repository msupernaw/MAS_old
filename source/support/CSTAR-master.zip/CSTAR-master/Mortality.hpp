/* 
 * File:   Mortality.hpp
 * Author: matthewsupernaw
 *
 * Created on December 16, 2014, 1:47 PM
 */

#ifndef MORTALITY_HPP
#define	MORTALITY_HPP

namespace cstar {


    namespace mortality {

        template<class T>
        class MortalityBase {
        };
        
        namespace age_based {

        }

        namespace size_based {

        }
    }
}

#endif	/* MORTALITY_HPP */

