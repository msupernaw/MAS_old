/* 
 * File:   Recruitment.hpp
 * Author: matthewsupernaw
 *
 * Created on December 16, 2014, 1:48 PM
 */

#ifndef RECRUITMENT_HPP
#define	RECRUITMENT_HPP

namespace cstar {



    namespace recruit {

        template<class T>
        class RecruitmentBase {
        };


        namespace age_based {

        }

        namespace size_based {

        }
    }
}

#endif	/* RECRUITMENT_HPP */

