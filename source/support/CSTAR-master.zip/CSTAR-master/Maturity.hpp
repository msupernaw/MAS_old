/* 
 * File:   Maturity.hpp
 * Author: matthewsupernaw
 *
 * Created on December 16, 2014, 1:49 PM
 */

#ifndef MATURITY_HPP
#define	MATURITY_HPP

namespace cstar {

    namespace maturity {

        template<class T>
        class MaturityBase {
        };

        namespace age_based {

        }

        namespace size_based {

        }

    }
}
#endif	/* MATURITY_HPP */

