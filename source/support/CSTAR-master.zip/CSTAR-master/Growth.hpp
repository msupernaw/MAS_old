/* 
 * File:   Growth.hpp
 * Author: matthewsupernaw
 *
 * Created on December 16, 2014, 1:48 PM
 */

#ifndef GROWTH_HPP
#define	GROWTH_HPP

namespace cstar {

    namespace growth {

        template<class T>
        class GrowthBase {
        };
        namespace age_based {

        }

        namespace size_based {

        }

    }
}
#endif	/* GROWTH_HPP */

