/* 
 * File:   Traits.hpp
 * Author: Matthew
 *
 * Created on December 30, 2014, 10:37 AM
 */

#ifndef TRAITS_HPP
#define	TRAITS_HPP


/*
 A place for type promotion, etc.
 */
namespace cstar{
    
    namespace traits{
        
    }
    
}

#endif	/* TRAITS_HPP */

